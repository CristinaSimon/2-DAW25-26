<?php declare( strict_types = 1 ); ?>
<?php
	# This page intentionally left blank
