import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-pagina404',
  imports: [RouterLink],
  templateUrl: './pagina404.html',
  styleUrl: './pagina404.css',
})
export class Pagina404 {

}
