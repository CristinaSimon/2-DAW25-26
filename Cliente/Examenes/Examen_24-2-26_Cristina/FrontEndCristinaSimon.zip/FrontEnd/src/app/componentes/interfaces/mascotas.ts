export interface Mascotas {
    nombre: string,
    raza:string,
    edad:number,
    precio:number,
    valoracion:string
}
