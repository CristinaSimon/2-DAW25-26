<?php
session_start();
echo "llego a borrar.php";
$alum=$_SESSION['alum'];
echo "$alum[id]";